﻿$(document).ready(function () {
    //Section to modify dates to current date, not section to modify if changed
    let today = new Date().toISOString().slice(0, 10);
    $("#start").val(today);
    $("#end").val(today);
    $("#start").attr("min", today);
    $("#end").attr("min", today);

    let flight = null;

    //Set price for Delta and Economy on page load
    $.ajax({
        type: "GET",
        url: "https://localhost:44342/api/Destination/GetFlight/Delta",
        contentType: "application/json/; charset=utf-8",
        dataType: "json",
        success: function (data) {
            flight = data;
            $("#flight-price").val(flight.EconomyPrice);

        }
    })
    $("#flight").change(function () {
        let getFlightString = "https://localhost:44342/api/Destination/GetFlight/" + $("#flight option:selected").text();
        $.ajax({
            type: "GET",
            url: getFlightString,
            contentType: "application/json/; charset=utf-8",
            dataType: "json",
            success: function (data) {
                flight = data;
                let flightClass = $("#flight-class option:selected").text();
                if (flightClass == "Economy Class") {
                    $("#flight-price").val(flight.EconomyPrice);
                } else if (flightClass == "Business Class") {
                    $("#flight-price").val(flight.BusinessPrice);
                } else {
                    $("#flight-price").val(flight.FirstPrice);
                }
            }
        })
    })
    $("#flight-class").change(function () {
        let flightClass = $("#flight-class option:selected").text();
        if (flightClass == "Economy Class") {
            $("#flight-price").val(flight.EconomyPrice);
        } else if (flightClass == "Business Class") {
            $("#flight-price").val(flight.BusinessPrice);
        } else {
            $("#flight-price").val(flight.FirstPrice);
        }
    })
    $("#start").change(function () {
        let endMin = $(this).val();
        $("#end").attr("min", endMin)
        $("#end").val(endMin);
    })
    $("#add-to-cart").click(function () {
        let stringURL = "https://localhost:44342/api/Destination/InsertFlightOrder/"
        let flightName = null;
        let flightClass = null;
        let flightPrice = null;
        let numSeats = parseInt($("#numSeats").val());
        if (isNaN(numSeats) == false || isNaN(numRooms) == false) {
                flightName = $("#flight").val();
                flightClass = $("#flight-class").val();
                flightPrice = parseInt($("#flight-price").val());

            let tripStart = $("#start").val();
            let tripEnd = $("#end").val();

            let tripOrigin = $("#state-select-origin").val();
            let tripDestination = $("#state-select-destination").val();
            let orderData = "origin=" + tripOrigin + "&destination=" + tripDestination + "&company=" + flightName + "&flightClass=" + flightClass + "&numSeats=" + numSeats +
                "&tripStart=" + tripStart + "&tripEnd=" + tripEnd + "&cost=" + flightPrice;
            
            $.ajax({
                type: "POST",
                url: stringURL,
                contentType: "application/x-www-form-urlencoded",
                dataType: "json",
                data: orderData,
                success: alert("Your order was added to the cart"),
                error: function (data) {
                    $("flight-price").val(data);
                }
            })
        } else {
            alert("One of the inputs for either Number of rooms or Number of flights is not an int")
        }
    })
    $("#checkout").click(function () {
        window.location.href = "http://localhost:1337/Checkout.html";
    })
})
﻿window.onload = function(){
    alert("Bookings page has loaded");
}